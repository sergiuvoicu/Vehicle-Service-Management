
enum Transmisie {
	
	MANUALA,
	AUTOMATA

}
