
public enum TipPolita {
	
	STANDARD,
	DISCOUNT

}
